var require = meteorInstall({"lib":{"collections":{"editor_contact.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/editor_contact.js                                                              //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
var _mongo = require('meteor/mongo');                                                             // 1
                                                                                                  //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                 // 2
                                                                                                  //
var EditorContact = new _mongo.Mongo.Collection('editor_contact');                                // 4
var schema = new _aldeedSimpleSchema.SimpleSchema({                                               // 5
  name: {                                                                                         // 6
    type: String,                                                                                 // 7
    label: "name",                                                                                // 8
    max: 100                                                                                      // 9
  },                                                                                              // 6
  phone: {                                                                                        // 11
    type: String,                                                                                 // 12
    label: "phone",                                                                               // 13
    optional: true,                                                                               // 14
    max: 100                                                                                      // 15
  },                                                                                              // 11
  mobile: {                                                                                       // 17
    type: String,                                                                                 // 18
    label: "mobile",                                                                              // 19
    optional: true,                                                                               // 20
    max: 100                                                                                      // 21
  },                                                                                              // 17
  wechat: {                                                                                       // 23
    type: String,                                                                                 // 24
    label: "wechat",                                                                              // 25
    optional: true,                                                                               // 26
    max: 100                                                                                      // 27
  },                                                                                              // 23
  email: {                                                                                        // 29
    type: String,                                                                                 // 30
    label: "email",                                                                               // 31
    optional: true,                                                                               // 32
    max: 100                                                                                      // 33
  },                                                                                              // 29
  address: {                                                                                      // 35
    type: String,                                                                                 // 36
    label: "address",                                                                             // 37
    optional: true,                                                                               // 38
    max: 200                                                                                      // 39
  },                                                                                              // 35
  comment: {                                                                                      // 41
    type: String,                                                                                 // 42
    label: "comment",                                                                             // 43
    optional: true,                                                                               // 44
    max: 600                                                                                      // 45
  }                                                                                               // 41
});                                                                                               // 5
EditorContact.attachSchema(schema);                                                               // 48
                                                                                                  //
exports['default'] = EditorContact;                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./editor_contact",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/index.js                                                                       //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
exports.EditorContact = undefined;                                                                //
                                                                                                  //
var _editor_contact = require('./editor_contact');                                                // 1
                                                                                                  //
var _editor_contact2 = _interopRequireDefault(_editor_contact);                                   //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
exports.EditorContact = _editor_contact2['default'];                                              //
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"mocking.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/mocking.js                                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
"use strict";                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
var contact = exports.contact = {                                                                 // 1
  name: "小编",                                                                                     // 2
  phone: "1234567",                                                                               // 3
  mobile: "13244477888",                                                                          // 4
  wechat: "wechat-string",                                                                        // 5
  email: "name@email.com",                                                                        // 6
  address: "公司地址",                                                                                // 7
  comment: "简单注释，请大家随便联系，微信最好"                                                                    // 8
};                                                                                                // 1
                                                                                                  //
var experts = exports.experts = [{                                                                // 12
  imgUrl: "/imgs/xingji.png",                                                                     // 14
  name: "邢继",                                                                                     // 15
  title: "“华龙一号”总设计师",                                                                            // 16
  description: "中国核电工程有限公司副总经理、总工程师、“华龙一号”总设计师，致力于核电工程的设计研究及管理工作"                                 // 17
}, {                                                                                              // 13
  imgUrl: "/imgs/yujunsong.png",                                                                  // 20
  name: "于俊崇",                                                                                    // 21
  title: "中国工程科学院院士",                                                                             // 22
  description: "中国工程科学院院士，著有“核电发展势在必行，提高和安全文化素养是关键”等"                                             // 23
}, {                                                                                              // 19
  imgUrl: "/imgs/wangliming.png",                                                                 // 26
  name: "王黎明",                                                                                    // 27
  title: "中核集团核燃料领域首席专家",                                                                         // 28
  description: "中核集团核燃料领域首席专家，著有'创新是科技进步的动力之源'"                                                   // 29
}, {                                                                                              // 25
  imgUrl: "/imgs/yeqiqin.png",                                                                    // 32
  name: "叶奇蓁",                                                                                    // 33
  title: "中国工程科学院院士",                                                                             // 34
  description: "中国工程科学院院士，著有“我国核电仪控系统的自主化之路”等"                                                    // 35
}];                                                                                               // 31
                                                                                                  //
var companies = exports.companies = [{                                                            // 38
  committee: "钱智民",                                                                               // 40
  title: "理事长",                                                                                   // 41
  name: "中国核工业集团公司"                                                                               // 42
}, {                                                                                              // 39
  committee: "祖斌",                                                                                // 45
  title: "副理事长",                                                                                  // 46
  name: "中国核工业建设集团公司"                                                                             // 47
}, {                                                                                              // 44
  committee: "王永福",                                                                               // 50
  title: "副理事长",                                                                                  // 51
  name: "中国华能集团公司"                                                                                // 52
}, {                                                                                              // 49
  committee: "王平",                                                                                // 55
  title: "副理事长",                                                                                  // 56
  name: "中国大唐集团公司"                                                                                // 57
}, {                                                                                              // 54
  committee: "余剑锋",                                                                               // 60
  title: "副理事长",                                                                                  // 61
  name: "中国电力投资集团公司"                                                                              // 62
}, {                                                                                              // 59
  committee: "郑建能",                                                                               // 65
  title: "副理事长",                                                                                  // 66
  name: "中国第二重型机械集团公司"                                                                            // 67
}];                                                                                               // 64
////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/util.js                                                                                    //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
var Color = exports.Color = {                                                                     // 2
  almostWhite: '#fbfdfb',                                                                         // 3
  grayWhite: '#f5f5fa',                                                                           // 4
  gallery: '#eee',                                                                                // 5
  middleGray: '#bfbfbf',                                                                          // 6
  primaryButton: '#2181c6',                                                                       // 7
  primaryText: '#015DA0',                                                                         // 8
  menuBgGray: '#353644',                                                                          // 9
  darkSpaceGray: '#323238',                                                                       // 10
                                                                                                  //
  primary: '#810707'                                                                              // 12
};                                                                                                // 2
                                                                                                  //
var isMobileDevice = function isMobileDevice() {                                                  // 15
  return (/(iphone|ipod|ipad|android)/gi.test(navigator.userAgent)                                // 15
  );                                                                                              // 15
};                                                                                                // 15
                                                                                                  //
exports['default'] = {                                                                            //
  isMobileDevice: isMobileDevice                                                                  // 18
};                                                                                                // 17
////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"configs":{"init.js":["/lib/collections","/lib/mocking",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/configs/init.js                                                                         //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  if (!_collections.EditorContact.findOne()) {                                                    // 5
    _collections.EditorContact.insert(_mocking.contact);                                          // 6
  }                                                                                               // 7
};                                                                                                // 8
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _mocking = require('/lib/mocking');                                                           // 2
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods":{"contact.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/contact.js                                                                      //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.methods({                                                                        // 6
    'contact.save': function contactSave(contactId, contact) {                                    // 7
      _collections.EditorContact.update(contactId, { $set: contact });                            // 8
    }                                                                                             // 9
  });                                                                                             // 6
};                                                                                                // 11
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
                                                                                                  //
var _check = require('meteor/check');                                                             // 3
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./contact",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/index.js                                                                        //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  (0, _contact2['default'])();                                                                    // 4
};                                                                                                // 5
                                                                                                  //
var _contact = require('./contact');                                                              // 1
                                                                                                  //
var _contact2 = _interopRequireDefault(_contact);                                                 //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"publications":{"contact.js":["/lib/collections","meteor/meteor",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/contact.js                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.publish('editor.contact', function () {                                          // 5
    return _collections.EditorContact.find();                                                     // 6
  });                                                                                             // 7
};                                                                                                // 8
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./contact",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/index.js                                                                   //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  (0, _contact2['default'])();                                                                    // 4
};                                                                                                // 5
                                                                                                  //
var _contact = require('./contact');                                                              // 1
                                                                                                  //
var _contact2 = _interopRequireDefault(_contact);                                                 //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"main.js":["./publications","./methods","./configs/init",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/main.js                                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
var _publications = require('./publications');                                                    // 1
                                                                                                  //
var _publications2 = _interopRequireDefault(_publications);                                       //
                                                                                                  //
var _methods = require('./methods');                                                              // 2
                                                                                                  //
var _methods2 = _interopRequireDefault(_methods);                                                 //
                                                                                                  //
var _init = require('./configs/init');                                                            // 3
                                                                                                  //
var _init2 = _interopRequireDefault(_init);                                                       //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
(0, _publications2['default'])();                                                                 // 5
(0, _methods2['default'])();                                                                      // 6
(0, _init2['default'])();                                                                         // 7
                                                                                                  //
Meteor.startup(function () {                                                                      // 9
  console.log("--- server started --- ");                                                         // 10
});                                                                                               // 11
////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./lib/collections/editor_contact.js");
require("./lib/collections/index.js");
require("./lib/mocking.js");
require("./lib/util.js");
require("./server/configs/init.js");
require("./server/methods/contact.js");
require("./server/methods/index.js");
require("./server/publications/contact.js");
require("./server/publications/index.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
