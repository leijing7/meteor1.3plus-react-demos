var require = meteorInstall({"lib":{"collections":{"companies.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/companies.js                                                                   //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
var _mongo = require('meteor/mongo');                                                             // 1
                                                                                                  //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                 // 2
                                                                                                  //
var Companies = new _mongo.Mongo.Collection('companies');                                         // 4
var schema = new _aldeedSimpleSchema.SimpleSchema({                                               // 5
  committee: {                                                                                    // 6
    type: String,                                                                                 // 7
    label: "contact_name",                                                                        // 8
    max: 100                                                                                      // 9
  },                                                                                              // 6
  title: {                                                                                        // 11
    type: String,                                                                                 // 12
    label: "contact_title",                                                                       // 13
    max: 100                                                                                      // 14
  },                                                                                              // 11
  name: {                                                                                         // 16
    type: String,                                                                                 // 17
    label: "company_name",                                                                        // 18
    max: 100                                                                                      // 19
  }                                                                                               // 16
});                                                                                               // 5
Companies.attachSchema(schema);                                                                   // 22
                                                                                                  //
exports['default'] = Companies;                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"editor_contact.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/editor_contact.js                                                              //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
var _mongo = require('meteor/mongo');                                                             // 1
                                                                                                  //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                 // 2
                                                                                                  //
var EditorContact = new _mongo.Mongo.Collection('editor_contact');                                // 4
var schema = new _aldeedSimpleSchema.SimpleSchema({                                               // 5
  name: {                                                                                         // 6
    type: String,                                                                                 // 7
    label: "name",                                                                                // 8
    max: 100                                                                                      // 9
  },                                                                                              // 6
  phone: {                                                                                        // 11
    type: String,                                                                                 // 12
    label: "phone",                                                                               // 13
    optional: true,                                                                               // 14
    max: 100                                                                                      // 15
  },                                                                                              // 11
  mobile: {                                                                                       // 17
    type: String,                                                                                 // 18
    label: "mobile",                                                                              // 19
    optional: true,                                                                               // 20
    max: 100                                                                                      // 21
  },                                                                                              // 17
  wechat: {                                                                                       // 23
    type: String,                                                                                 // 24
    label: "wechat",                                                                              // 25
    optional: true,                                                                               // 26
    max: 100                                                                                      // 27
  },                                                                                              // 23
  email: {                                                                                        // 29
    type: String,                                                                                 // 30
    label: "email",                                                                               // 31
    optional: true,                                                                               // 32
    max: 100                                                                                      // 33
  },                                                                                              // 29
  address: {                                                                                      // 35
    type: String,                                                                                 // 36
    label: "address",                                                                             // 37
    optional: true,                                                                               // 38
    max: 200                                                                                      // 39
  },                                                                                              // 35
  comment: {                                                                                      // 41
    type: String,                                                                                 // 42
    label: "comment",                                                                             // 43
    optional: true,                                                                               // 44
    max: 600                                                                                      // 45
  },                                                                                              // 41
  createdAt: {                                                                                    // 47
    type: Date,                                                                                   // 48
    label: "created date"                                                                         // 49
  },                                                                                              // 47
  updatedAt: {                                                                                    // 51
    type: Date,                                                                                   // 52
    label: "updated date"                                                                         // 53
  }                                                                                               // 51
});                                                                                               // 5
EditorContact.attachSchema(schema);                                                               // 56
                                                                                                  //
exports['default'] = EditorContact;                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./editor_contact","./companies","./notice",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/index.js                                                                       //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
exports.Notice = exports.Companies = exports.EditorContact = undefined;                           //
                                                                                                  //
var _editor_contact = require('./editor_contact');                                                // 1
                                                                                                  //
var _editor_contact2 = _interopRequireDefault(_editor_contact);                                   //
                                                                                                  //
var _companies = require('./companies');                                                          // 2
                                                                                                  //
var _companies2 = _interopRequireDefault(_companies);                                             //
                                                                                                  //
var _notice = require('./notice');                                                                // 3
                                                                                                  //
var _notice2 = _interopRequireDefault(_notice);                                                   //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
exports.EditorContact = _editor_contact2['default'];                                              //
exports.Companies = _companies2['default'];                                                       //
exports.Notice = _notice2['default'];                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"notice.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/notice.js                                                                      //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
var _mongo = require('meteor/mongo');                                                             // 1
                                                                                                  //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                 // 2
                                                                                                  //
var Notice = new _mongo.Mongo.Collection('notice');                                               // 4
var schema = new _aldeedSimpleSchema.SimpleSchema({                                               // 5
  text: {                                                                                         // 6
    type: String,                                                                                 // 7
    label: "notice text",                                                                         // 8
    max: 4000                                                                                     // 9
  },                                                                                              // 6
  createdAt: {                                                                                    // 11
    type: Date,                                                                                   // 12
    label: "created date"                                                                         // 13
  },                                                                                              // 11
  updatedAt: {                                                                                    // 15
    type: Date,                                                                                   // 16
    label: "updated date"                                                                         // 17
  }                                                                                               // 15
});                                                                                               // 5
Notice.attachSchema(schema);                                                                      // 20
                                                                                                  //
exports['default'] = Notice;                                                                      //
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"mocking.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/mocking.js                                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
"use strict";                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
var contact = exports.contact = {                                                                 // 1
  name: "小编",                                                                                     // 2
  phone: "1234567",                                                                               // 3
  mobile: "13244477888",                                                                          // 4
  wechat: "wechat-string",                                                                        // 5
  email: "name@email.com",                                                                        // 6
  address: "公司地址",                                                                                // 7
  comment: "简单注释，请大家随便联系，微信最好"                                                                    // 8
};                                                                                                // 1
                                                                                                  //
var experts = exports.experts = [{                                                                // 12
  imgUrl: "/imgs/xingji.png",                                                                     // 14
  name: "邢继",                                                                                     // 15
  title: "“华龙一号”总设计师",                                                                            // 16
  description: "中国核电工程有限公司副总经理、总工程师、“华龙一号”总设计师，致力于核电工程的设计研究及管理工作"                                 // 17
}, {                                                                                              // 13
  imgUrl: "/imgs/yujunsong.png",                                                                  // 20
  name: "于俊崇",                                                                                    // 21
  title: "中国工程科学院院士",                                                                             // 22
  description: "中国工程科学院院士，著有“核电发展势在必行，提高和安全文化素养是关键”等"                                             // 23
}, {                                                                                              // 19
  imgUrl: "/imgs/wangliming.png",                                                                 // 26
  name: "王黎明",                                                                                    // 27
  title: "中核集团核燃料领域首席专家",                                                                         // 28
  description: "中核集团核燃料领域首席专家，著有'创新是科技进步的动力之源'"                                                   // 29
}, {                                                                                              // 25
  imgUrl: "/imgs/yeqiqin.png",                                                                    // 32
  name: "叶奇蓁",                                                                                    // 33
  title: "中国工程科学院院士",                                                                             // 34
  description: "中国工程科学院院士，著有“我国核电仪控系统的自主化之路”等"                                                    // 35
}];                                                                                               // 31
                                                                                                  //
var companies = exports.companies = [{                                                            // 38
  committee: "钱智民",                                                                               // 39
  title: "理事长",                                                                                   // 40
  name: "中国核工业集团公司"                                                                               // 41
}, {                                                                                              // 38
  committee: "祖斌",                                                                                // 44
  title: "副理事长",                                                                                  // 45
  name: "中国核工业建设集团公司"                                                                             // 46
}, {                                                                                              // 43
  committee: "王永福",                                                                               // 49
  title: "副理事长",                                                                                  // 50
  name: "中国华能集团公司"                                                                                // 51
}, {                                                                                              // 48
  committee: "王平",                                                                                // 54
  title: "副理事长",                                                                                  // 55
  name: "中国大唐集团公司"                                                                                // 56
}, {                                                                                              // 53
  committee: "余剑锋",                                                                               // 59
  title: "副理事长",                                                                                  // 60
  name: "中国电力投资集团公司"                                                                              // 61
}, {                                                                                              // 58
  committee: "郑建能",                                                                               // 64
  title: "副理事长",                                                                                  // 65
  name: "中国第二重型机械集团公司"                                                                            // 66
}];                                                                                               // 63
                                                                                                  //
var conferences = exports.conferences = [{                                                        // 69
  name: "2016 年亚洲核工业技术管理论坛",                                                                      // 71
  date: new Date(),                                                                               // 72
  suburb: "海淀区",                                                                                  // 73
  address: "中国北京海淀区北大街 1899 号 8 楼"                                                                // 74
}, {                                                                                              // 70
  name: "2017 年世界核工业技术高峰",                                                                        // 77
  date: new Date("2017-01-05"),                                                                   // 78
  suburb: "徐汇区",                                                                                  // 79
  address: "中国上海徐汇区南京路 67 号逸夫楼 3 层"                                                               // 80
}, {                                                                                              // 76
  name: "2017 中美核技术交流年会",                                                                         // 83
  date: new Date("2017-09-05"),                                                                   // 84
  suburb: "San Jose",                                                                             // 85
  address: "18 Mill St, San Jose, California USA"                                                 // 86
}];                                                                                               // 82
                                                                                                  //
var notice = exports.notice = {                                                                   // 89
  text: "\n  ## 中国核工业征稿\n\n  中国核工业现面向社会全面征稿，来稿请直接通过网站在线系统投稿或发我刊邮箱。稿件题头下一行必须写清第一作者的详细地址和电话，包括手机号码；有通讯作者的请给予标注，并写明邮箱。本期刊的审稿周期为1-3周，过期尚未收到投稿的作者可另投其他期刊。\n\n  ### 学术杂志网绿色投稿同道优势介绍：\n  1. 审稿快：《中国核工业》内部审稿通道为1-3周，大大缩短了投、审、刊的时间；\n  2. 发刊快：凡是在本站编辑部投稿并确定录用的稿件，可享受1-6个月见刊；\n  3. 沟通好：专业老师对你的稿件编辑情况、排刊情况、见刊情况进行及时沟通；\n  4. 有保障：有专业的专家教授团队，为您免费修改需要返修的《中国核工业》论文；\n  5. 送期刊：凡是在本站投稿的作者，均可免费获得《中国核工业》杂志一本；\n  6. 我们还可以为你提供CNKI反抄袭检测、继教学分、著书代理、英文翻译等服务。\n\n  ### 一、《中国核工业》投稿要求\n  1. 投稿格式：投稿杂志名称-投稿文章标题-作者姓名-联系电话-联系地址；\n  2. 投稿文章不违反宪法和法律，不损害公共利益。\n  3. 投稿文章是作者独立取得的原创性、学术研究成果，不侵犯任何著作权和版权，不损害第三方的其他权利；所有来稿必须通过我刊社的“中国知网期刊学术不端文献检测系统”检测，文字复制比必须低于用稿标准，引用部分文字的要在参考文献中注明；署名和作者单位无误。\n  4. 我刊初审周期为1－7个工作日，请在投稿3天后查看您的邮箱，收阅我们的审稿回复或用稿通知；若20天内没有收到我们的回复，稿件可自行处理。\n  5. 按用稿通知上的要求办理相关手续后，稿件将进入出版程序；\n  6. 杂志出刊后，我们会按照您提供的地址免费奉寄样刊。\n  7. 未曾以任何形式用任何文种在国内外公开发表过。\n\n  ### 二、《中国核工业》投稿付费须知\n\n  凡是投入本站并确定发表的稿件，杂志社出具录取通知书，其作者须支付相关费用，本网站提供相关收据证明，并签订书面合同。网站免费对稿件进行修改以确保杂志社通过，稿件录用后，网站提供杂志社刊发的相关录用通知单，作者收到通知单后支付全部款项。\n\n  ### 三、《中国核工业》版权告知\n\n  1. 所有向《中国核工业》投递的作品无论是否发表，作者均依照《中华人民共和国著作权法》享有著作权。\n  2. 所有向《中国核工业》投稿作品及其相关合作机构，享有使用权。"
};                                                                                                // 89
                                                                                                  //
var magazines = exports.magazines = [{                                                            // 123
  name: "中国核电"                                                                                    // 124
}, {                                                                                              // 123
  name: "原子能科学技术"                                                                                 // 126
}, {                                                                                              // 125
  name: "核技术"                                                                                     // 128
}, {                                                                                              // 127
  name: "核电子学与探测技术"                                                                               // 130
}, {                                                                                              // 129
  name: "核化学与放射化学"                                                                                // 132
}, {                                                                                              // 131
  name: "核科技进展"                                                                                   // 134
}, {                                                                                              // 133
  name: "铀矿冶"                                                                                     // 136
}, {                                                                                              // 135
  name: "核技术"                                                                                     // 138
}, {                                                                                              // 137
  name: "核科学与工程"                                                                                  // 140
}, {                                                                                              // 139
  name: "核动力工程"                                                                                   // 142
}, {                                                                                              // 141
  name: "辐射防护"                                                                                    // 144
}, {                                                                                              // 143
  name: "强激光与粒子束"                                                                                 // 146
}, {                                                                                              // 145
  name: "核聚变与等离子物理"                                                                               // 148
}, {                                                                                              // 147
  name: "同位素"                                                                                     // 150
}, {                                                                                              // 149
  name: "核标准计量与质量"                                                                                // 152
}, {                                                                                              // 151
  name: "中国核工业"                                                                                   // 154
}];                                                                                               // 153
                                                                                                  //
var strategies = exports.strategies = [{ title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }, { title: '如何做那万绿葱葱中的一点红!' }];
                                                                                                  //
var skills = exports.skills = [{ title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }, { title: '拯救你溺水的标题!' }];
                                                                                                  //
var latestArticles = exports.latestArticles = [{ authors: ["吴炳晨"], title: "核电厂外电源系统保护带负荷试验替补方法研究" }, { authors: ["徐智", "鲍麒"], title: "潜在通路分析技术在AP1000核电厂主回路设计中的应用" }, { authors: ["吴炳晨"], title: "核电厂外电源系统保护带负荷试验替补方法研究" }, { authors: ["徐智", "鲍麒"], title: "潜在通路分析技术在AP1000核电厂主回路设计中的应用" }, { authors: ["吴炳晨"], title: "核电厂外电源系统保护带负荷试验替补方法研究" }, { authors: ["徐智", "鲍麒"], title: "潜在通路分析技术在AP1000核电厂主回路设计中的应用" }];
////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/util.js                                                                                    //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
var Color = exports.Color = {                                                                     // 2
  almostWhite: '#fbfdfb',                                                                         // 3
  grayWhite: '#f5f5fa',                                                                           // 4
  gallery: '#eee',                                                                                // 5
  middleGray: '#bfbfbf',                                                                          // 6
  primaryButton: '#2181c6',                                                                       // 7
  primaryText: '#015DA0',                                                                         // 8
  menuBgGray: '#353644',                                                                          // 9
  darkSpaceGray: '#323238',                                                                       // 10
                                                                                                  //
  primary: '#810707'                                                                              // 12
};                                                                                                // 2
                                                                                                  //
var isMobileDevice = function isMobileDevice() {                                                  // 15
  return (/(iphone|ipod|ipad|android)/gi.test(navigator.userAgent)                                // 15
  );                                                                                              // 15
};                                                                                                // 15
                                                                                                  //
exports['default'] = {                                                                            //
  isMobileDevice: isMobileDevice                                                                  // 18
};                                                                                                // 17
////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"configs":{"init.js":["/lib/collections","/lib/mocking",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/configs/init.js                                                                         //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  if (!_collections.EditorContact.findOne()) {                                                    // 5
    _mocking.contact.createdAt = new Date().valueOf();                                            // 6
    _mocking.contact.updatedAt = new Date().valueOf();                                            // 7
    _collections.EditorContact.insert(_mocking.contact);                                          // 8
  }                                                                                               // 9
  if (!_collections.Notice.findOne()) {                                                           // 10
    _mocking.notice.createdAt = new Date().valueOf();                                             // 11
    _mocking.notice.updatedAt = new Date().valueOf();                                             // 12
    _collections.Notice.insert(_mocking.notice);                                                  // 13
  }                                                                                               // 14
};                                                                                                // 15
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _mocking = require('/lib/mocking');                                                           // 2
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods":{"contact.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/contact.js                                                                      //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.methods({                                                                        // 6
    'contact.save': function contactSave(contactId, contact) {                                    // 7
      contact.updatedAt = new Date().valueOf();                                                   // 8
      _collections.EditorContact.update(contactId, { $set: contact });                            // 9
    }                                                                                             // 10
  });                                                                                             // 6
};                                                                                                // 12
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
                                                                                                  //
var _check = require('meteor/check');                                                             // 3
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./contact","./notice",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/index.js                                                                        //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  (0, _contact2['default'])();                                                                    // 5
  (0, _notice2['default'])();                                                                     // 6
};                                                                                                // 7
                                                                                                  //
var _contact = require('./contact');                                                              // 1
                                                                                                  //
var _contact2 = _interopRequireDefault(_contact);                                                 //
                                                                                                  //
var _notice = require('./notice');                                                                // 2
                                                                                                  //
var _notice2 = _interopRequireDefault(_notice);                                                   //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"notice.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/notice.js                                                                       //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.methods({                                                                        // 6
    'notice.save': function noticeSave(noticeId, notice) {                                        // 7
      notice.updatedAt = new Date().valueOf();                                                    // 8
      _collections.Notice.update(noticeId, { $set: notice });                                     // 9
    }                                                                                             // 10
  });                                                                                             // 6
};                                                                                                // 12
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
                                                                                                  //
var _check = require('meteor/check');                                                             // 3
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"publications":{"contact.js":["/lib/collections","meteor/meteor",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/contact.js                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.publish('editor.contact', function () {                                          // 5
    return _collections.EditorContact.find();                                                     // 6
  });                                                                                             // 7
};                                                                                                // 8
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./contact","./notice",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/index.js                                                                   //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  (0, _contact2['default'])();                                                                    // 5
  (0, _notice2['default'])();                                                                     // 6
};                                                                                                // 7
                                                                                                  //
var _contact = require('./contact');                                                              // 1
                                                                                                  //
var _contact2 = _interopRequireDefault(_contact);                                                 //
                                                                                                  //
var _notice = require('./notice');                                                                // 2
                                                                                                  //
var _notice2 = _interopRequireDefault(_notice);                                                   //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"notice.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/notice.js                                                                  //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.publish('notice', function () {                                                  // 6
    return _collections.Notice.find();                                                            // 7
  });                                                                                             // 8
};                                                                                                // 9
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
                                                                                                  //
var _check = require('meteor/check');                                                             // 3
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"main.js":["./publications","./methods","./configs/init",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/main.js                                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
var _publications = require('./publications');                                                    // 1
                                                                                                  //
var _publications2 = _interopRequireDefault(_publications);                                       //
                                                                                                  //
var _methods = require('./methods');                                                              // 2
                                                                                                  //
var _methods2 = _interopRequireDefault(_methods);                                                 //
                                                                                                  //
var _init = require('./configs/init');                                                            // 3
                                                                                                  //
var _init2 = _interopRequireDefault(_init);                                                       //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
(0, _publications2['default'])();                                                                 // 5
(0, _methods2['default'])();                                                                      // 6
(0, _init2['default'])();                                                                         // 7
                                                                                                  //
Meteor.startup(function () {                                                                      // 9
  console.log("--- server started --- ");                                                         // 10
});                                                                                               // 11
////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./lib/collections/companies.js");
require("./lib/collections/editor_contact.js");
require("./lib/collections/index.js");
require("./lib/collections/notice.js");
require("./lib/mocking.js");
require("./lib/util.js");
require("./server/configs/init.js");
require("./server/methods/contact.js");
require("./server/methods/index.js");
require("./server/methods/notice.js");
require("./server/publications/contact.js");
require("./server/publications/index.js");
require("./server/publications/notice.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
